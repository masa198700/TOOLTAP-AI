# ToolTap AI

This is the full working source code for ToolTap AI.

Includes:
- Cover Letter Generator
- Resume Rewriter
- Interview Tools
- Stripe Integration
- Supabase Auth
- Dark Mode
- Credit System

To run:
1. Clone repo
2. Add .env.local with OpenAI, Supabase, Stripe keys
3. `npm install && npm run dev`
